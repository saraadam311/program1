board = [0,1,2,3,4,5,6,7,8]
boardLog = [0, 0, 0, 0, 0, 0, 0, 0, 0]

player = 'A' 

def tic_tac_toe ():
    print ('|' ,board[0],'|',board[1] ,'|', board[2],'|')
    print ('--------------------')
    print ('|' ,board[3],'|',board[4] ,'|', board[5],'|')
    print ('--------------------')
    print ('|' ,board[6],'|',board[7] ,'|', board[8],'|')

def move(x1,x2):
    board[x2] = x1
    tic_tac_toe()
    boardLog[x2] = x1

def odd (x, x2):
    if (x>9):
        x = int (input ('enter a number in range 0 - 9'))
    while  (x%2==0):
        x = int(input ('enter an odd number:'))
    move (x ,x2)      

def even (x ,x2) :
    if (x>9):
        x = int (input ('enter a number in range 0 - 9'))
    while  (x%2!=0):
        x = int(input ('enter an even number:'))
    move (x ,x2)        
        
    
def turn(s):
    print ('its '+ s +' turn')
    x = int (input ('enter a number in range 0 - 9 : '))
    x1 = int (input ('enter the places number: '))
    is_num_repeted = True
    while (is_num_repeted):
        for i in boardLog :
            if (x==i):
                print ("This number has already been used")
                x = int (input ('enter a number in range 0 - 9 :'))
            else :
                is_num_repeted = False
    if player == 'A':
        odd(x, x1)
    else: 
        even(x, x1)          

print('Tic Tac Toe')
print ('player A should enter odd numbers only'+' and player B should enter even numbers only')
print ('the player with the ood numbers start')
tic_tac_toe ()
while (True):
    turn(player)
    if (boardLog[0] + boardLog[1] + boardLog[2] == 15):
          print ('you are the winner')
          break
    if (boardLog[0] + boardLog[3] + boardLog[6] == 15):
          print ('you are the winner')
          break
    if (boardLog[1] + boardLog[4] + boardLog[7] == 15):
          print ('you are the winner')
          break
    if (boardLog[3] + boardLog[4] + boardLog[5] == 15):
          print ('you are the winner')
          break
    if (boardLog[2] + boardLog[5] + boardLog[8] == 15):
          print ('you are the winner')
          break
    if (boardLog[6] + boardLog[7] + boardLog[8] == 15):
          print ('you are the winner')
          break
    if player == 'A':
        player = 'B'
    else:
        player = 'A' 
